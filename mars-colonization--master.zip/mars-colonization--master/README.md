# mars-colonization

## project -entertain the crew 

Engage the Crew by building an unbeatable Tic Tac Toe game Using Minimax algorithm powered by AI.


